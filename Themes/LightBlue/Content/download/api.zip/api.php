<?php

// User properties -- Fill these properties with your properties
$websiteID = 0;
$username = "username";
$redirectUrl = "http://google.com";

// Script Properties
$checkVoteUrl = "http://datop100.com/CheckVoted/" .$websiteID;
$voteUrl = "http://datop100.com/Vote/" . $username . "/" . $websiteID . "?Redirect=" . $redirectUrl;
$timeOutConnection = 5;


// Functions
function HasVoted($url, $timeout) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	curl_setopt($ch, CURLOPT_FAILONERROR, true);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_AUTOREFERER, true);
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36");
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}

// Validate redirect url
if (filter_var($redirectUrl, FILTER_VALIDATE_URL) == true)
{
		// Get content of remote server
		$contentHasVoted = HasVoted($checkVoteUrl, $timeOutConnection);
		
		if($contentHasVoted == "false")
		{
			// redirect to voting page
			header("Location: ".$voteUrl);
			exit();
		}
		else
		{
			// redirect to redirect url -- user has already voted // remote server death // error
			header("Location: ".$redirectUrl);
		}
}
else
{
	 die("The redirect url is not a valid url");
}

?>