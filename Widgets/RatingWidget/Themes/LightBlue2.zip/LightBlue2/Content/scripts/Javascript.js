﻿$(document).ready(function () {
    var Page;
    var CategoryID;
    var SearchText;

    ReplaceBrokenImages();

    // Load new websites
    $("#loadwebsites").click(function () {
        $("#loadwebsites").val("Loading Websites..")
        Page = document.getElementById('page').value;
        CategoryID = document.getElementById('categoryID').value;
        SearchText = document.getElementById('searchText').value;
        if (CategoryID == "" && SearchText == "") {
            Url = "/LoadWebsites?page=" + Page;
        }
        else if (SearchText != "") {
            Url = "/LoadWebsites?page=" + Page + "&search=" + SearchText;
        }
        else {
            Url = "/LoadWebsites?page=" + Page + "&categoryid=" + CategoryID;
        }
        $.get(Url, function (data) {
            var Info = $('#newwebsites').html();
            $('#newwebsites').html(Info + data);
            $("#loadwebsites").val("Load more websites");
            document.getElementById('page').value = parseInt(Page) + 1;
            ReplaceBrokenImages();
        });
    });


    // Replace broken images
    function ReplaceBrokenImages() {
        $(".bannerImage img").each(function (index) {
            $(this).error(function () {
                $(this).attr("src", "/Themes/LightBlue/Content/images/thumbnail.png");
            });
            // Reset for IE
            $(this).attr("src", $(this).attr("src"));
        });
    }

    var model = '<div class="overlay" style="width: 100%; height: 100%; opacity: 0.5; background-color: black; position: absolute; top: 0px; left: 0px; display:none;"></div>'
    jQuery('body').append(model);

  
    $(".modal-header .close").click(function () {
        $(".overlay").hide()
        $(".modal").hide('slow');
    });
    $(".modal-footer #close").click(function () {
        $(".overlay").hide()
        $(".modal").hide('slow');
    });

    $('body').on('click', '.stats', function () {
        $(this).closest(".ranking").find(".statsbox").toggle('slow');
    });

    $('body').on('click', '.flag', function () {
        var Username = ($(this).closest(".ranking").find(".username").val());
        $("#ReportUserModel_Username").val(Username);
        var Website = ($(this).closest(".ranking").find(".website").val());
        $("#ReportUserModel_Website").val(Website);
        $(".overlay").css({ 'height': $(document).height(), 'width': $(document).width() }).show();



        $(".modal").show('slow');
    });

    // Code List click
    $('#codeWebsites li a').click(function () {
        $(this).parent().find('textarea').toggle('slow');
    });

    // Toggle statistics from website statistics page
    $('#statsWebsites .websiteName').click(function () {
        $(this).parent().find('.pageStatistics').toggle('slow');
    });
 
});
