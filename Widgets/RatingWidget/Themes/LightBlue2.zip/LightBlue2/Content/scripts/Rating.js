﻿
    var clicked = false;

 

function SubmitRating1() {
    if (clicked == true) {
        clicked = false;
        LeaveRating();
    }
    else {
        document.getElementById('star1').style.backgroundImage = "url(/Themes/LightBlue//Themes/LightBlue/Content/images/star.png)";
        document.getElementById('RatingStar').value = 1
        clicked = true;
    }
}
function SubmitRating2() {
    if (clicked == true) {
        clicked = false;
        LeaveRating();
    }
    else {
        document.getElementById('star1').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star2').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('RatingStar').value = 2
        clicked = true;
    }
}
function SubmitRating3() {
    if (clicked == true) {
        clicked = false;
        LeaveRating();
    }
    else {
        document.getElementById('star1').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star2').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star3').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('RatingStar').value = 3
        clicked = true;
    }
}
function SubmitRating4() {
    if (clicked == true) {
        clicked = false;
        LeaveRating();
    }
    else {
        document.getElementById('star1').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star2').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star3').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star4').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('RatingStar').value = 4
        clicked = true;
    }
}
function SubmitRating5() {
    if (clicked == true) {
        clicked = false;
        LeaveRating();
    }
    else {
        document.getElementById('star1').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star2').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star3').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star4').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star5').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('RatingStar').value = 5
        clicked = true;
    }
}

function LeaveRating() {
    if (clicked == false) {
        document.getElementById('star1').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star-off.png)";
        document.getElementById('star2').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star-off.png)";
        document.getElementById('star3').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star-off.png)";
        document.getElementById('star4').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star-off.png)";
        document.getElementById('star5').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star-off.png)";
        document.getElementById('RatingStar').value = ""
    }
}

function Rating1() {
    if (clicked == false) {
        document.getElementById('star1').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
    }
}
function Rating2() {
    if (clicked == false) {
        document.getElementById('star1').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star2').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
    }
}
function Rating3() {
    if (clicked == false) {
        document.getElementById('star1').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star2').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star3').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
    }
}
function Rating4() {
    if (clicked == false) {
        document.getElementById('star1').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star2').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star3').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star4').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
    }
}
function Rating5() {
    if (clicked == false) {
        document.getElementById('star1').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star2').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star3').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star4').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
        document.getElementById('star5').style.backgroundImage = "url(/Themes/LightBlue/Content/images/star.png)";
    }
}
