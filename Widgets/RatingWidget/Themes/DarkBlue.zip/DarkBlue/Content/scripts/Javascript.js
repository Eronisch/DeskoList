﻿/// <reference path="Javascript.js" />
$(document).ready(function () {
    var Page;
    // Load new websites
    $("#loadwebsites").click(function () {
        $("#loadwebsites").val("Loading Websites..")
        Page = document.getElementById('page').value;
        Url = "/LoadWebsites?page=" + Page;
        $.get(Url, function (data) {
            var Info = $('#newwebsites').html();
            $('#newwebsites').html(Info + data);
            $("#loadwebsites").val("Load more websites");
            document.getElementById('page').value = parseInt(Page) + 1;
        });
    });

    var model = '<div class="overlay" style="width: 100%; height: 100%; opacity: 0.5; background-color: black; position: absolute; top: 0px; left: 0px; display:none;"></div>'
    jQuery('body').append(model);

  
    $(".modal-header .close").click(function () {
        $(".overlay").hide()
        $(".modal").hide('slow');
    });
    $(".modal-footer #close").click(function () {
        $(".overlay").hide()
        $(".modal").hide('slow');
    });

    $('body').on('click', '.stats', function () {
        $(this).closest(".ranking").find(".statsbox").toggle('slow');
    });

    $('body').on('click', '.flag', function () {
        var Username = ($(this).closest(".ranking").find(".username").val());
        $("#Username").val(Username);
        var Website = ($(this).closest(".ranking").find(".website").val());
        $("#Website").val(Website);
        $(".overlay").css({ 'height': $(document).height(), 'width': $(document).width() }).show();



        $(".modal").show('slow');
    });

 
});
